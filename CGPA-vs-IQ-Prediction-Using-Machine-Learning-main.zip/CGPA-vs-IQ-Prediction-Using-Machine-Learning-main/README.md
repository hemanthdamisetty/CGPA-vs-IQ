# CGPA-vs-IQ-Prediction-Using-Machine-Learning
CGPA vs IQ Prediction Using Machine Learning
